public interface RequestBinConst {
    public static final String DEFAULT_ENCODING = "";
    public static final int MAX_LENGTH  = 255; // Max length on the" wire"
}
